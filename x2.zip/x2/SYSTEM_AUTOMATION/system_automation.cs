﻿using System;
using x1;

namespace x2
{
    class system_automation : datacode
    {
        public string program_name = "System Automation Library (AUTOTECH LIBRARY by Apolyon)";

        public void data(object x)
        {

        }
    }
}