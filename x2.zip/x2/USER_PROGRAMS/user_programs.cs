﻿using System;
using x1;

/*
 *  ACCOUNTING
 *  AUDIO (sound placement, sound block, sound cancel, white noise, headphones)
 *  BANKING 
 *  BUILDER (Architecture Design - housing, weapons, office, electronics, mechanics)
 *  BROWSER (FILE, DOCUMENT, WEBSITE, COMPUTER, SERVER, NETWORK, OBJECT, PRINTER)
 *  CAMERAS (Environment Mapping, Object SCANNING, IDCUBE VERIFY, OCR, security, alarm)
 *  CALCULATOR (10 Key w/ plugins)
 *  DATABANK (NETWORK FILE STORAGE, LOCAL STORAGE OF NET OBJECTS, LOCAL WIKIPEDIA, LOCAL MUSIC, MOVIES)
 *  CLICK (Text Editor & Integrated Development Environment)
 *  CLOCK (Time, Alarms, Measurement, Dates)
 *  COMPILER (A B C C++ C# >H< FPHP PHP PERL CGI A)
 *  CRAWLER (localnet, internet, privatenet, ossnet: autofind files, code, images etc.)
 *  DIAGRAM (diagram, flowchart, schematic, interface, mechanics, electronics*send cake to visio*)
 *  DIRECTORY (personal contacts, people, companies, websites, notes)
 *  ENVIRONMENT (motion, temperature, humidity, wind, light, sound)
 *  GEOGRAPHY (map, route, topography, planet, resources) [view/create/edit]
 *  GRAPHIX (photo, images, objects, vector, gui, 3d, screenshots) [create/edit]
 *  MESSENGER (email, mail, txt, phone, voip, voicemail, irc, spacetime)
 *  PLANNER (project management, task management, calendar, meetings, events)
 *  PRINTER (paper, plastic, metal)
 *  SETTINGS (x2 system, virtual machines, display, etc)
 *  SPREADSHEET (mechanical paper)
 *  TYPE (word processor, papertouch)
 *  VIEWER (images, documents, objects, etc)
 */

namespace x2
{
    class user_programs : datacode
    {
        public void data()
        {

        }
    }
}
