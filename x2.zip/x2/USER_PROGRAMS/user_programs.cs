﻿using System;
using x1;

/*
 *  ACCOUNTING (personal, business, reoccuring, military, bar)
 *  AUDIO (sound placement, sound block, sound cancel, white noise, headphones)
 *  BANKING (all about personal and business banking, credit cards, credits, digital assets, safetybox)
 *  BOWSER  (explore and manage FILE, DOCUMENT, WEBSITE, COMPUTER, SERVER, NETWORK, OBJECT, PRINTER IN OTHER CASTLES)
 *  BUILDER (Architecture Design - housing, weapons, office, networks, electronics, mechanics, VIRTUALit)
 *  CALCULATOR (10 Key w/ plugins)
 *  CAMERAS (Environment Mapping, Object SCANNING, IDCUBE VERIFY, OCR, security, alarm)  
 *  CLICK (Text Editor & Integrated Development Environment)
 *  CLOCK (Time, Alarms, Measurement, Dates)
 *  COMMUNICATOR (email, mail, txt, phone, voip, voicemail, irc, spacetime, autobots)
 *  COMPILER (A B C C++ C# >H< FPHP PHP PERL CGI A)
 *  CRAWLER (localnet, internet, privatenet, ossnet: autofind files, code, images, everything etc.)
 *  CREDENTIALS (generate, store, verify, scan, share, retrieve, clone, authenticate, IDCUBE)
 *  DATABANK (NETWORK FILE STORAGE, NET OBJECTS, system services access, LOCAL WIKIPEDIA, LOCAL MUSIC, MOVIES, ANYTHING)
 *  DIAGRAM (diagram, flowchart, schematic, interface, mechanics, electronics, 3Dit)
 *  DIRECTORY411 (personal contacts, people, companies, websites, notes, miniDNS)
 *  EMERGENCY (police, fire, ems, medical monitoring)
 *  FIX2 (system repair, system take-apart, dependency scanning, program tracker, filetrack, autorestore, run-time-recompile,custom disk defrag, system diagnostics, program profiler, system profiler, emergency backups, program state, network override)
 *  GARBAGE (empty trash, restore, move, save-to-media, wipe, quarantine, test, recycle)
 *  GEARME (majors and minors, asset tracking, procurement, supply chain tracking)
 *  GEOGRAPHY (map, route, topography, planet, resources) [view/create/edit]
 *  GRAPHIX (photo, images, objects, vector, gui, 3d, screenshots) [create/edit]
 *  HARDWARE (hardconnectIT, guns, cars, phone, satgear, watch, autocode, diagnostics, upgrade, settings)
 *  LETTER (word processor, papertouch)
 *  MIDDLEMACHINE (Virtualization Hypervisor, virtual keyboard, SERVERS, network os devices, and localnet --)  
 *  MOVIEGO (stream, edit, dvd, record)  
 *  MUSICPRO (stream, store, play, currate, share, analyze, add, remove, record, compile, create, broadcast)
 *  PLANNER (project management, task fusion, calendar, meetings, events)
 *  PRINTER (paper, plastic, metal, cubes)
 *  SETTINGS (x2 system, virtual machines, display, etc)
 *  SNAPSHOT (mission review, projector, slide shows, whiteboard, group space)
 *  SPREADSHEET (mechanical paper)
 *  TASK (reoccuring, botcode completion, secretary service access, system maintenance, botcode completion!)
 *  VIEWER (images, documents, objects, etc)
  */

namespace x2
{
    class user_programs : datacode
    {
        public void data(object x)
        {

        }
    }
}
