﻿using System;
using x1;

/*
 *  DEVICE_MANAGEMENT_SERVICES (device tracking, configuration, remote access)
 *  EMERGENCY_SERVICES (alert, scanning, notification, EMS procedures, defib)
 *  IDENTITY_SERVICES (registration, personal records, etc)
 *  LANGUAGE_SERVICES (translation, dictation, dictionary, etc)
 *  SECRETARY_SERVICES (automated assistants)
 *  TELEPHONY_SERVICES (switchboard, videopipes, signals review, signal streaming)
 */

namespace x2
{
    class user_services : datacode
    {
        public void data()
        {

        }
    }
}