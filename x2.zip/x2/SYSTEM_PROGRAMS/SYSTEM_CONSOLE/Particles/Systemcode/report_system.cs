﻿using System;
using x1;
namespace x2
{
    class report_system : systemcode
    {
        public void system(object x)
        {
            Console.WriteLine("> console online");
        }
    }
}