﻿using System;
using x1;

namespace x2
{
    class console_datacode : datacode
    {
        public string program_name = "System Console ('console' by Apolyon)";

        public void data(object x)
        {
            
        }
    }
}
