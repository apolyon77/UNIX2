﻿using System;
using System.Collections;
using System.Threading;


// x2 - by Commander Apolyon
// Not for public distribution

namespace x2
{
    public class user_console : program
    {
        public void code(object x)
        {
            // use apache2 at http://192.168.1.1            
            Console.WriteLine("> user_console online");
        }
    }
}
