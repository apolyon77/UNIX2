﻿using System;
using System.IO;
using System.Collections;
using System.Threading;

// x2 - by Commander Apolyon
// Not for public distribution

namespace x2
{
    public class system_journal : program
    {
        public void code(object x)
        {
            Console.WriteLine("> system_journal online");
        }
    }
}

