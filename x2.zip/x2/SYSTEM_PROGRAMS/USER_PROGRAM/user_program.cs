﻿using System;
using System.Collections;
using System.Threading;

// x2 - by Commander Apolyon
// Not for public distribution

namespace x2
{
    public class user_program : program
    {
        public void code()
        {
            Console.WriteLine("> user_program online");
        }
    }
}