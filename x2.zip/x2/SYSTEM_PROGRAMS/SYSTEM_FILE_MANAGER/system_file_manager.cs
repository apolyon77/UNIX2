﻿using System;
using System.Collections;
using System.Threading;

// x2 - by Commander Apolyon
// Not for public distribution

namespace x2
{
    public class system_file_manager : program
    {
        public void code()
        {
            Console.WriteLine("> system_file_manager online");
        }
    }
}