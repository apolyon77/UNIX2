﻿using System;
using System.Collections;
using System.Threading;

// x2 - by Commander Apolyon
// Not for public distribution

namespace x2
{
    public class system_messenger : program
    {
        public void code()
        {
            Console.WriteLine("> system_messenger online");
        }
    }
}
