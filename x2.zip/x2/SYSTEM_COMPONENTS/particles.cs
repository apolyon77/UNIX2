﻿using System;
using System.Threading;
using x1;
namespace x2
{
    public class particles
    {
        public Thread          thread;
        public EventWaitHandle handle;

        public particles(datacode x)
        {
            handle = new AutoResetEvent(true);
            thread = new Thread(x.data); thread.Start(this);
        }

        ~particles()
        {
            Console.WriteLine("> particle offline");
        }
    }
}
