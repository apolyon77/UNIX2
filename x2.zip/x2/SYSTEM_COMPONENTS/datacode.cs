﻿using System;
using x1;
namespace x2
{
    public interface datacode
    {
        void data(object x);
    }
}
