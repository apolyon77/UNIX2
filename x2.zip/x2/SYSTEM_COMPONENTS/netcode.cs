﻿using System;
using x1;
namespace x2
{
    public interface netcode
    {
        void net(object x);
    }
}
