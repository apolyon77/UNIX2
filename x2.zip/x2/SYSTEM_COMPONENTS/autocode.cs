﻿using System;
using x1;
namespace x2
{
    public interface autocode
    {
        void auto(object x);
    }
}
