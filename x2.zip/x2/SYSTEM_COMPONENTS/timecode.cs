﻿using System;
using x1;
namespace x2
{
    public interface timecode
    {
        void time(object x);
    }
}
