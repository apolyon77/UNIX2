﻿using System;
using x1;
namespace x2
{
    public interface systemcode
    {
        void system(object x);
    }
}
