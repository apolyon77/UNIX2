using System;
using x1;

// x2 - by Commander Apolyon
// Not for public distribution

namespace x2
{
    public class system_services : program
    {
        public void code()
        {
            
        }
    }
}